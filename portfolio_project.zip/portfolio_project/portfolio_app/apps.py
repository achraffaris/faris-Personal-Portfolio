from django.apps import AppConfig


class PortfolioAppConfig(AppConfig):
    name = 'portfolio_app'
